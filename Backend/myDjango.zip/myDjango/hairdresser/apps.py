from django.apps import AppConfig


class HairdresserConfig(AppConfig):
    name = 'hairdresser'
